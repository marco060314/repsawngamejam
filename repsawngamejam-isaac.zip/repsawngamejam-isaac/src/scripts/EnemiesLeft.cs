using Godot;
using System;

public partial class EnemiesLeft : Counter
{
	EnemiesLeft(): base("Enemies Left:"){}
}
