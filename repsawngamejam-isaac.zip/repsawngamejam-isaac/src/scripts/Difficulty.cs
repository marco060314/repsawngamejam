public enum Difficulty{
	EASY,MEDIUM,HARD
}
