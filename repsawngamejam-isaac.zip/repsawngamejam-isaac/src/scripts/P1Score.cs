using Godot;
using System;

public partial class P1Score : Counter
{
	public P1Score(): base("Player 1 Score:"){}
}
