using Godot;
using System;

public partial class Round : Counter
{
	public Round(): base("Round:"){}
}
