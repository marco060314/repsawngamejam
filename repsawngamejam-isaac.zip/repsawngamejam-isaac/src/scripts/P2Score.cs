using Godot;
using System;

public partial class P2Score : Counter
{
	public P2Score(): base("Player 2 Score:"){}
}
